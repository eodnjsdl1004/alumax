<?
$menu["menu300"] = array (
    array("300000", "게시판관리", ""),
    array("300100", "게시판관리", "$g4[admin_path]/board_list.php"),
    array("300200", "게시판그룹관리", "$g4[admin_path]/boardgroup_list.php"),
    array("-"),
    array("300300", "인기검색어관리", "$g4[admin_path]/popular_list.php"),
    array("300400", "인기검색어순위", "$g4[admin_path]/popular_rank.php"),
);
?>