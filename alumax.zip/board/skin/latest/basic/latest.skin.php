<?
if (!defined("_GNUBOARD_")) exit; // ���� ������ ���� �Ұ� 
?>
<table width="340" cellpadding="0" cellspacing="0" border="0" style="margin:7px 0 0 10px;">
<? for ($i=0; $i<count($list); $i++) { ?>
  <tr height="21">
	<td width="275"><a href="<?=($bo_table=="Latest")? str_replace("bo_table=", "bo_table=".$list[$i]['bo_table'], $list[$i]['href']):$list[$i]['href']?>"><img src="/img/icon/ic_dot02.gif" style="margin:0 3px 3px 8px;"><?=$list[$i]['subject']?>
	</a></td>
	<td width="65" class="Gray01"><?=str_replace("-",".",$list[$i]['datetime'])?></td>
</tr>
<? } ?>

<? if (count($list) == 0) { ?><tr><td colspan=2 align=center height=50><font color=#6A6A6A>�Խù��� �����ϴ�.</a></td></tr><? } ?>

</table>
