<?

if ($g4['https_url']) {
    $outlogin_url = $_GET['url'];
    if ($outlogin_url) {
        if (preg_match("/^\.\.\//", $outlogin_url)) {
            $outlogin_url = urlencode($g4[url]."/".preg_replace("/^\.\.\//", "", $outlogin_url));
        }
        else {
            $purl = parse_url($g4[url]);
            if ($purl[path]) {
                $path = urlencode($purl[path]);
                $urlencode = preg_replace("/".$path."/", "", $urlencode);
            }
            $outlogin_url = $g4[url].$urlencode;
        }
    }
    else {
        $outlogin_url = $g4[url];
    }
}
else {
    $outlogin_url = $urlencode;
}
?>

<script type="text/javascript" src="<?=$g4[path]?>/js/capslock.js"></script>
<script type="text/javascript">
// ���Ľ� �α� ����
var bReset = true;
function chkReset(f)
{
    if (bReset) { if ( f.mb_id.value == '���̵�' ) f.mb_id.value = ''; bReset = false; }
    document.getElementById("pw1").style.display = "none";
    document.getElementById("pw2").style.display = "";
}
</script>


<!-- �α��� �� �ܺηα��� ���� -->
<form name="fhead" method="post" onsubmit="return fhead_submit(this);" autocomplete="off" style="margin:0px;">
<input type="hidden" name="url" value="<?=$outlogin_url?>">
				<table width="198" cellpadding="0"  cellspacing="0" border="0" style="margin:33px 0 0 9px;">
					<tr>
						<td width="148">
							<table width="142" cellspacing="0" border="0">
								<tr>
									<td width="142"><input name="mb_id" type="text" style="width:138px;" maxlength="20" required itemname="���̵�" value='���̵�' onMouseOver='chkReset(this.form);' onFocus='chkReset(this.form);'></td>
								</tr>
								<tr>
									<td width="142"><span id="pw1"><input type="text" style="width:138px;" maxlength="20" required itemname="�н�����" value='�н�����' onMouseOver='chkReset(this.form);' onfocus='chkReset(this.form);'></span><span id="pw2" style="display:none;"><input name="mb_password" id="outlogin_mb_password" type="password" style="width:138px;" maxlength="20" itemname="�н�����" onMouseOver='chkReset(this.form);' onfocus='chkReset(this.form);' onKeyPress="check_capslock(event, 'outlogin_mb_password');"></span></td>
								</tr>
							</table>
						</td>
						<td width="50"><input type="image" src="/img/button/btn_login01.gif" style="width:50px;height:50px;border:0px;"></td>
					</tr>
					<tr>
						<td colspan="2" class="Login_Join"><a href="/board/bbs/register.php"><img src="/img/icon/ic_arrow02.gif" style="margin:0 2px 0 0">ȸ������</a><a href="javascript:win_password_lost();" style="cursor:pointer;"><img src="/img/icon/ic_arrow02.gif" style="margin:0 2px 0 17px">���̵�/��й�ȣã��</a></td>
					</tr>
				</table>

</form>

<script type="text/javascript">
function fhead_submit(f)
{
    if (!f.mb_id.value) {
        alert("ȸ�����̵� �Է��Ͻʽÿ�.");
        f.mb_id.focus();
        return false;
    }

    if (document.getElementById('pw2').style.display!='none' && !f.mb_password.value) {
        alert("�н����带 �Է��Ͻʽÿ�.");
        f.mb_password.focus();
        return false;
    }

    <?
    if ($g4[https_url])
        echo "f.action = '$g4[https_url]/$g4[bbs]/login_check.php';";
    else
        echo "f.action = '$g4[bbs_path]/login_check.php';";
    ?>

    return true;
}
</script>
<!-- �α��� �� �ܺηα��� �� -->
