<?
if (!defined("_GNUBOARD_")) exit;
?>

</td>
</tr>
<tr><td colspan=3 height=22 bgcolor=#F2F2F2 align=right><a href='#gnuboard4_admin_head'><img src='<?=$g4['admin_path']?>/img/top.gif' border=0></a>&nbsp;</td></tr>
</table><br><br>
<!-- <p>����ð� : <?=get_microtime() - $begin_time;?> -->

<script type='text/javascript' src='<?=$g4['admin_path']?>/admin.js'></script>

<? 
include_once("$g4[path]/tail.sub.php");
?>