<script>
location.href="main.php";
</script>