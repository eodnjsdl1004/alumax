<?
$mysql_host = '49.247.131.220';
$mysql_user = 'root';
;$mysql_password = '1q2w3e!';
$mysql_password = 'kada!1234';
$mysql_db = 'alumax';
?>