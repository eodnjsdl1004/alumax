<?
$mysql_host = '121.78.152.55';
$mysql_user = 'root';
$mysql_password = '1q2w3e!';
$mysql_db = 'alumax';
?>