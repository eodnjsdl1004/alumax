package com.alumax.gw.exception;

public class MemberInsertException extends Exception{
	private static final long serialVersionUID = 1L;
	
	public MemberInsertException(){}
	public MemberInsertException(String message){
		super(message);
	}
}
