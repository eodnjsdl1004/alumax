package com.alumax.gw.exception;

public class MemberDetailException extends Exception{
	
	private static final long serialVersionUID = 1L;
	public MemberDetailException(){}
	public MemberDetailException(String message){
		super(message);
	}
}
