package com.alumax.gw.service;


import java.lang.reflect.Method;
import java.util.ResourceBundle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alumax.gw.model.dao.DataAccessObject;

public class ModelFactory {
	private Log log = LogFactory.getLog(ModelFactory.class);
	private static ResourceBundle resourceBundle;
	
	static{
		resourceBundle = ResourceBundle.getBundle("modelconfiguration");
	}
	
	public static MemberService getMemberService() throws Exception {
		String property = resourceBundle.getString("service.member");
		Class serviceClass = Class.forName(property);
		Method method = serviceClass.getMethod("getInstance", null);
		MemberService memberService = (MemberService)method.invoke(null,null);
		return memberService;
	}

	public static MemberService getAdminMemberService() throws Exception {
		String property = resourceBundle.getString("service.admin.member");
		Class serviceClass = Class.forName(property);
		Method method = serviceClass.getMethod("getInstance", null);
		MemberService memberService = (MemberService)method.invoke(null,null);
		return memberService;
	}

	

	public static DataAccessObject getMemberDAO() throws Exception{
		String property = resourceBundle.getString("dao.member");
		Class daoClass = Class.forName(property);
		DataAccessObject dao = (DataAccessObject)daoClass.newInstance();
		return dao;
	}
	
	public static DataAccessObject getAdminMemberDAO() throws Exception{
		String property = resourceBundle.getString("dao.admin.member");
		Class daoClass = Class.forName(property);
		DataAccessObject dao = (DataAccessObject)daoClass.newInstance();
		return dao;
	}

	public static DataAccessObject getBoardDAO() throws Exception{
		String property = resourceBundle.getString("dao.board");
		Class daoClass = Class.forName(property);
		DataAccessObject dao = (DataAccessObject)daoClass.newInstance();
		return dao;
	}
	
	public static DataAccessObject getBoardFiledDAO() throws Exception{
		String property = resourceBundle.getString("dao.boardfile");
		Class daoClass = Class.forName(property);
		DataAccessObject dao = (DataAccessObject)daoClass.newInstance();
		return dao;
	}
	
	public static DataAccessObject getGoodsDAO() throws Exception{
		String property = resourceBundle.getString("dao.goods");
		Class daoClass = Class.forName(property);
		DataAccessObject dao = (DataAccessObject)daoClass.newInstance();
		return dao;
	}
	
	public static DataAccessObject getGoodsFiledDAO() throws Exception{
		String property = resourceBundle.getString("dao.goodsfile");
		Class daoClass = Class.forName(property);
		DataAccessObject dao = (DataAccessObject)daoClass.newInstance();
		return dao;
	}
	

}
