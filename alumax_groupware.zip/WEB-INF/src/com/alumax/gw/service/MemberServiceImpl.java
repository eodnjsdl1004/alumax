package com.alumax.gw.service;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alumax.gw.model.dao.DataAccessObject;
import com.alumax.gw.model.dto.MemberDTO;


public class MemberServiceImpl implements MemberService{

	private static Log log = LogFactory.getLog(MemberServiceImpl.class);
	private static MemberServiceImpl instance;
	static{
		instance = new MemberServiceImpl();
	}
	private MemberServiceImpl(){}
	
	public List find(MemberDTO memberDTO, String gubun) {
		try{
			List result = null;
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
				result = memberDAO.select(memberDTO,gubun);
			log.info("result.size(): "+result.size());
			if(result.size()==0) return null;
			return result;
		}catch(Exception e){
			log.error("exception :"+e.toString());
			return null;
		}
	}

	public static MemberServiceImpl getInstance(){
		if(log.isInfoEnabled()){
			log.info("MemberServiceImpl ��ü ����");
		}
		return instance;
	}
	
	public MemberDTO select(String no){
		try{
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			MemberDTO result = (MemberDTO)memberDAO.select(no);
			return result;
		}catch(Exception e){
			log.error("exception :"+e.toString());
			return null;
		}
	}

	public int login(String id, String password) {
		try{
			MemberDTO memberDTO = new MemberDTO();
			memberDTO.setM_id(id);
			memberDTO.setM_pw(password);
			log.info("id: "+id);
			log.info("password: "+password);

			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			List result = memberDAO.select(memberDTO,"login");
			log.info("result.size(): "+result.size());
			
			//svc_member table�� ���� ���. 
			if(result==null || result.size()==0){
				return MemberService.LOGIN_NO_EXIST_ID;
			}
				
			//svc_member table�� ���̵�,�н����尡 ������ ȸ���� �������� ��� (dy1414/141415)
		
			MemberDTO data = (MemberDTO)result.get(0);
			
			//�α��� ����.
			log.info("�α��� ����");
			return MemberService.LOGIN_SUCCESS;
		}catch(Exception e){
			log.error("exception :"+e.toString());
			return MemberService.LOGIN_NO_EXIST_ID;
		}
	}

	public long count(String condition) {
		try{
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			long result = memberDAO.count(null);
			return result;
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}

	public int delete(String id) {
		try{
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			int result = memberDAO.delete(id, null);
			return result;
		}catch(Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	public String insert(MemberDTO memberDTO) {
		try {
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			Integer result_cnt = (Integer)memberDAO.insert(memberDTO);
			if(result_cnt==1){
				return MemberService.INSERT_SUCCESS;
			}else{
				return MemberService.INSERT_FAIL;
			}
		} catch (SQLException e) {
			log.error("exception :"+e.toString());
			return MemberService.INSERT_DB_EXCEPTION;
		} catch (Exception e) {
			log.error("exception :"+e.toString());
			return MemberService.INSERT_UNKNOWN_EXCEPTION;
		}
	}

	public List select(long rowsPerPage, long currentPage, String condition, String order) {
		try{
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			List result = memberDAO.select(rowsPerPage, currentPage, condition, order);
			log.info("result.size(): "+result.size());
			return result;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public List<MemberDTO> select(Object key, String condition) {
		try{
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			List<MemberDTO> result = memberDAO.select(key, condition);
			log.info("result.size():"+result.size());
			
			return result;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}

	public int update(MemberDTO memberDTO, String gubun) {
		try {
			log.info("getMemberDAO()");
			DataAccessObject memberDAO = ModelFactory.getMemberDAO();
			Integer result_cnt = (Integer)memberDAO.update(memberDTO,gubun);
			if(result_cnt==1){
				return MemberService.UPDATE_SUCCESS;
			}else{
				return MemberService.UPDATE_FAIL;
			}
		} catch (SQLException e) {
			log.error("exception :"+e.toString());
			return MemberService.UPDATE_DB_EXCEPTION;
		} catch (Exception e) {
			log.error("exception :"+e.toString());
			return MemberService.UPDATE_UNKNOWN_EXCEPTION;
		}
	}

	public int update(MemberDTO memberDTO) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
