package com.alumax.gw.service;

import java.util.List;

import com.alumax.gw.model.dto.MemberDTO;

public interface MemberService {

	int LOGIN_SUCCESS=0;
	int LOGIN_NO_EXIST_ID=-1;
	int LOGIN_WRONG_PASSWORD=-2;
	int LOGIN_SAME_ID_EXIST=2;
	int LOGIN_CONFIRM_ID=3;
	
	String INSERT_SUCCESS="1000";
	String INSERT_FAIL="2000";
	String INSERT_UNKNOWN_EXCEPTION="3000";
	String INSERT_DB_EXCEPTION="3001";
	String INSERT_DB_CONNECTION_FAIL="3002";
	
	int UPDATE_SUCCESS=1;
	int UPDATE_FAIL=-1;
	int UPDATE_DB_EXCEPTION=0;
	int UPDATE_UNKNOWN_EXCEPTION=-2;
	
	int login(String id, String password);
	
	MemberDTO select(String no);
	
	List select(long rowsPerPage, long currentPage, String condition, String order);
	
	public List select(Object key, String condition);
	
	String insert(MemberDTO memberDTO);
	
	int delete(String id);
	
	int update(MemberDTO memberDTO);
	
	int update(MemberDTO memberDTO, String gubun);
	
	long count(String condition);
	
	List find(MemberDTO memberDTO,String gubun);
	
	
}
