package com.alumax.gw.util;

public class Paging {
	 private static int PAGE_COUNT = 10;
	 
	 public static String getGotoPageSelect(int totalRow, int page_size, int pageNo) {
	  String sReturn  = "";
	  
	  int totalPage = (totalRow / page_size) + ( ((totalRow % page_size) == 0) ? 0 : 1);
	  
	  // ��ü������������  option �� �����. 
	  for (int i=1;i<=totalPage;i++){
		  sReturn += "<option value='"+String.valueOf(i)+"' ";
		   if (i == pageNo){
			   sReturn += " selected ";
		   }
	   
		   sReturn += ">"+String.valueOf(i)+"/"+String.valueOf(totalPage)+"</option>\n ";
	  }
	  
	  return sReturn;
	 }
	 
	 public static void setPageCount(int page_size){
		 PAGE_COUNT = page_size;
	 }
	 
	 public static String getNextPageIndexes(String url, int totalRow, int page_size, int pageNo) {
	  String sReturn  = "";
	  
	  if( totalRow <= page_size ){
		  return sReturn;
	  }
	  
	  int startPage = ( ( ( (pageNo % PAGE_COUNT) == 0) ? pageNo-1 : pageNo) / PAGE_COUNT) * PAGE_COUNT + 1;
	  int totalPage = (totalRow / page_size) + ( ((totalRow % page_size) == 0) ? 0 : 1);
	  int endPage  = ( (totalPage - startPage) >= PAGE_COUNT ) ? (startPage + PAGE_COUNT-1) : totalPage;
	  
	  sReturn += "<a href='" + url + "currentPage=1&countPerPage="+page_size+"'><img src=\"/images/sub/page1.gif\" alt=\"ó�� ������\" /></a>&nbsp;&nbsp;";

	  if( pageNo > PAGE_COUNT ) {
		  sReturn += "<a href='" + url + "&currentPage=" + (startPage-1) + "&countPerPage="+page_size+"'><img src=\"/images/sub/pre_bt.gif\" alt=\"���� ������\" /></a>&nbsp;&nbsp;";
	  }
	  for( int i= startPage; i <= endPage; i++ ) {
		  sReturn += (i == pageNo) ? 
	       "<b><a href='" + url + "currentPage="+i+"&countPerPage="+page_size+"'>"+i+"</a></b>&nbsp;&nbsp;" :
	       "<a href='" + url + "currentPage="+i+"&countPerPage="+page_size+"'>"+i+"</a>&nbsp;&nbsp;";
	  }
	  if( endPage != totalPage) {
		  sReturn += "<a href='" + url + "currentPage=" + (endPage+1) + "&countPerPage="+page_size+"'><img src=\"/images/sub/next_bt.gif\" alt=\"���� ������\" /></a>&nbsp;&nbsp;";
	  }

	  sReturn += "<a href='" + url + "currentPage=" + totalPage + "&countPerPage="+page_size+"'><img src=\"/images/sub/page_end.gif\" alt=\"������ ������\" /></a>";
	  
	  return sReturn;
	 }
	 
	 public static String getNextPageIndexes2(String url, int totalRow, int page_size, int pageNo) {
		  String sReturn  = "";
		  
		  if( totalRow <= page_size ){
			  return sReturn;
		  }
		  
		  int startPage = ( ( ( (pageNo % PAGE_COUNT) == 0) ? pageNo-1 : pageNo) / PAGE_COUNT) * PAGE_COUNT + 1;
		  int totalPage = (totalRow / page_size) + ( ((totalRow % page_size) == 0) ? 0 : 1);
		  int endPage  = ( (totalPage - startPage) >= PAGE_COUNT ) ? (startPage + PAGE_COUNT-1) : totalPage;
		  
		  if(pageNo != 1) {
			  sReturn += "<a href='" + url + "currentPage=1&countPerPage="+page_size+"'><img src=\"/images/sub/page1.gif\" alt=\"ó�� ������\" /></a>&nbsp;&nbsp;";
		  }
		  if( pageNo > PAGE_COUNT ) {
			  sReturn += "<a href='" + url + "&currentPage=" + (startPage-1) + "&countPerPage="+page_size+"'><img src=\"/images/sub/pre_bt.gif\" alt=\"���� ������\"></a>&nbsp;&nbsp;";
		  }
		  for( int i= startPage; i <= endPage; i++ ) {
			  sReturn += (i == pageNo) ? 
		       "<strong><font color=\"#0165AB\">"+i+"</font></strong>&nbsp;&nbsp;" :
		       "<a href='" + url + "currentPage="+i+"&countPerPage="+page_size+"'>"+i+"</a>&nbsp;&nbsp;";
		  }
		  if( endPage != totalPage) {
			  sReturn += "<a href='" + url + "currentPage=" + (endPage+1) + "&countPerPage="+page_size+"'><img src=\"/images/sub/next_bt.gif\" alt=\"���� ������\"></a>&nbsp;&nbsp;";
		  }
		  if(pageNo != totalPage) {
			  sReturn += "<a href='" + url + "currentPage=" + totalPage + "&countPerPage="+page_size+"'><img src=\"/images/sub/page_end.gif\" alt=\"������ ������\" /></a>";
		  }
		  return sReturn;
		 }
	 
	 public static String getNextPageScript(String Script, int totalRow, int page_size, int pageNo) {
	  String sReturn  = "";
	  
	  if( totalRow <= page_size )   
	    return sReturn;
	  
	  int startPage = ( ( ( (pageNo % PAGE_COUNT) == 0) ? pageNo-1 : pageNo) / PAGE_COUNT) * PAGE_COUNT + 1;
	  int totalPage = (totalRow / page_size) + ( ((totalRow % page_size) == 0) ? 0 : 1);
	  int endPage  = ( (totalPage - startPage) >= PAGE_COUNT ) ? (startPage + PAGE_COUNT-1) : totalPage;
	  
	  sReturn += "<table width='100%'><tr><td>&nbsp;</td>";
	  sReturn += "<td width='17'><a href='" + Script + "(" + "1)'><img src='images/pdweb/common/top/boardbtn01.gif' width='17' height='13' border='0'></a></td>";

	  if( pageNo > PAGE_COUNT ) {
	     sReturn += "<td width='13'><a href='" + Script + "(" + (startPage-1) + ")'><img src='images/pdweb/common/top/boardbtn02.gif' width='13' height='13' border='0'></a></td>";
	  }
	  sReturn += "<td width='130' align='center'><span class='sotit_05'>";
	  for( int i= startPage; i <= endPage; i++ ) {
	     sReturn += (i == pageNo) ? 
	       "<span class='sotit_04'><u><a href='" + Script + "("+i+")'>["+i+"]</a></u></span>&nbsp;" :
	       "<a href='" + Script + "("+i+")'>["+i+"]</a>&nbsp;";
	  }
	  sReturn += "</span></td>";
	  if( endPage != totalPage) {
	    sReturn += "<td width='13'><a href='" + Script + "(" + (endPage+1) + ")'><img src='images/pdweb/common/top/boardbtn03.gif' width='13' height='13' border='0'></a></td>";
	  }

	  sReturn += "<td width='17'><a href='" + Script + "(" + endPage + ")'><img src='images/pdweb/common/top/boardbtn04.gif' width='17' height='13' border='0'></a></td>";
	  sReturn += "<td>&nbsp;</td></tr></table>";
	  return sReturn;
	 }
	 
	 public static String getNextPageIndexes3(String url, int totalRow, int page_size, int pageNo) {
		  String sReturn  = "";
		  
		  if( totalRow <= page_size ){
			  return sReturn;
		  }
		  
		  int startPage = ( ( ( (pageNo % PAGE_COUNT) == 0) ? pageNo-1 : pageNo) / PAGE_COUNT) * PAGE_COUNT + 1;
		  int totalPage = (totalRow / page_size) + ( ((totalRow % page_size) == 0) ? 0 : 1);
		  int endPage  = ( (totalPage - startPage) >= PAGE_COUNT ) ? (startPage + PAGE_COUNT-1) : totalPage;

		  sReturn += "<td width=\"20\" align=\"right\"><a href='" + url + "currentPage=1&countPerPage="+page_size+"'><img src=\"/images/sub/page1.gif\" alt=\"�Ǿ����ΰ���\" width=\"15\" height=\"15\"></a></td>";
		  if( pageNo > PAGE_COUNT ) {
			  sReturn += "<a href='" + url + "&currentPage=" + (startPage-1) + "&countPerPage="+page_size+"'><td width=\"20\" align=\"right\"><img src=\"/images/sub/pre_bt.gif\" alt=\"�����ΰ���\" width=\"15\" height=\"15\"></a></td>";
		  }
		  sReturn += "<td width=\"150\" align=\"center\" class=\"pglink_menu\">";
		  for( int i= startPage; i <= endPage; i++ ) {
			  if(pageNo==i){
				  sReturn += "&nbsp;<a href='" + url + "currentPage="+i+"&countPerPage="+page_size+"'><span style='color:red;font-weight:bold;text-decoration:underline;'>"+i+"</span></a>&nbsp;";
			  }else{
				  sReturn += "&nbsp;<a href='" + url + "currentPage="+i+"&countPerPage="+page_size+"'>"+i+"</a>&nbsp;";
			  }
		  }
		  sReturn += "</td>";
		  if( endPage != totalPage) {
			  sReturn += "<td width=\"20\" align=\"left\"><a href='" + url + "currentPage=" + (endPage+1) + "&countPerPage="+page_size+"'><img src=\"/images/sub/next_bt.gif\" alt=\"��������������\" width=\"15\" height=\"15\"></a></td>";
		  }
		  sReturn += "<td width=\"20\" align=\"left\"><a href='" + url + "currentPage=" + totalPage + "&countPerPage="+page_size+"'><img src=\"/images/sub/page_end.gif\" alt=\"�ǵڷΰ���\" width=\"15\" height=\"15\"></a></td>";
		  
		  
		  
		  return sReturn;
		 }
		 
	 
	}
