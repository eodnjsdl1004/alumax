package com.alumax.gw.controller.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


public class MemberLogoutAction extends Action{
	private static Log log = LogFactory.getLog(MemberLogoutAction.class);
	
	public ActionForward execute(ActionMapping mapping, ActionForm form, 
			HttpServletRequest request, HttpServletResponse response) throws Exception{
		if(log.isInfoEnabled()){
			log.info("execute() Running");
		}
//		saveToken(request);	
		
		request.getSession().removeAttribute("return_url");
		request.getSession().removeAttribute("user");
		return mapping.findForward("goHome");
	}

}
