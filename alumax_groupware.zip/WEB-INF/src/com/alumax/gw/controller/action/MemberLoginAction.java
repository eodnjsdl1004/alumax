package com.alumax.gw.controller.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.util.RequestUtils;

import com.alumax.gw.controller.actionform.LoginActionForm;
import com.alumax.gw.model.dto.MemberDTO;
import com.alumax.gw.model.dto.UserDTO;
import com.alumax.gw.service.MemberService;
import com.alumax.gw.service.ModelFactory;

public class MemberLoginAction extends Action{
	private Log log = LogFactory.getLog(MemberLoginAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		log.info("Login check");
		LoginActionForm loginForm = (LoginActionForm)form;
		ActionErrors errors = new ActionErrors();
		
		MemberDTO memberDTO = new MemberDTO();
		RequestUtils.populate(memberDTO, request);

/*
		if (!isTokenValid(request)) {
            errors.add("error.transaction",
                       new ActionMessage("error.transaction.token"));
        }
       	resetToken(request);		
		        
		// Report any errors we have discovered back to the original form
		if (!errors.isEmpty()) {
		    saveErrors(request, errors);
 	        saveToken(request);

	        return mapping.findForward("index");
		}
*/		
		try{
			if(log.isInfoEnabled()){
				log.info("getM_id() : "+loginForm.getM_id());
				log.info("getM_pw() : "+loginForm.getM_pw());
			}
			
			MemberService memberService = ModelFactory.getMemberService();
			int result = memberService.login(loginForm.getM_id(),loginForm.getM_pw());
			if(result==memberService.LOGIN_SUCCESS ){
				UserDTO userDTO = new UserDTO();
				userDTO.setM_id(loginForm.getM_id());
				
				List result_login = memberService.find(memberDTO,"login");
				log.info("result_login.size(): "+result_login.size());
				MemberDTO memberDTO_login = (MemberDTO)result_login.get(0);
				
				log.info("memberDTO_login.getName(): "+memberDTO_login.getM_name());
				log.info("getId(): "+userDTO.getM_id());

				userDTO.setM_id(memberDTO_login.getM_id());
				userDTO.setM_name(memberDTO_login.getM_name());
				userDTO.setM_name(memberDTO_login.getM_name());
				
				userDTO.setLogin(true);
				
				request.getSession().setAttribute("user", userDTO);
				if(log.isInfoEnabled()){
					log.info("�α��� ����");
					log.info("���ǿ� UserDTO���");
				}
				log.info("request.getAttribute : "+request.getSession().getAttribute("return_url"));
				
				if(request.getSession().getAttribute("return_url")!=null){
					String return_url = request.getSession().getAttribute("return_url").toString();
					return new ActionForward("",return_url,true,"");
				}

				return mapping.findForward("success");
				
			}else if(result==memberService.LOGIN_NO_EXIST_ID){
				
				log.info("�������� ���� ���̵�/�н����� �Դϴ�.");
				errors.add("login.fail",new ActionMessage("errors.login.id",true));
				this.saveErrors(request, errors);
				return mapping.findForward("login_fail");
				
			}else{
				
				log.info("�α��� ����");
				errors.add("login.fail",new ActionMessage("errors.login.id",true));
				this.saveErrors(request, errors);
				return mapping.findForward("login_fail");
			}
			
		}catch(Exception e){
			errors.add("login.fail",new ActionMessage("errors.login",true));
			this.saveErrors(request, errors);
			log.error("exception :"+e.toString());
			return mapping.findForward("login_fail");
		}
			
	}
	
}
