package com.alumax.gw.controller.actionform;

import org.apache.struts.validator.ValidatorActionForm;

public class MemberActionForm extends ValidatorActionForm{
	private static final long serialVersionUID = 1L;
	private int no;
	private String m_id;
	private String m_pw;

	private String m_name;
	private String m_jumin1;
	private String m_jumin2;
	private String m_email1;
	private String m_email2;
	private String jumin_number;
	private String confirm_use;
	private int result_value;
	private String level;
	private String m_mailing;
	private String m_tel1;
	private String m_tel2;
	private String m_tel3;
	private String tel;
	private String m_hp1;
	private String m_hp2;
	private String m_hp3;
	private String hp;
	private String introduce;
	private String locale;
	private String m_zip1;
	private String m_zip2;
	private String zip;
	private String m_addr1;
	private String m_addr2;
	private String m_hpcomp;
	
	public String getM_hpcomp() {
		return m_hpcomp;
	}
	public void setM_hpcomp(String mHpcomp) {
		m_hpcomp = mHpcomp;
	}
	public String getM_mailing() {
		return m_mailing;
	}
	public void setM_mailing(String mMailing) {
		m_mailing = mMailing;
	}
	public String getM_tel1() {
		return this.m_tel1;
	}
	public void setM_tel1(String m_tel1) {
		this.m_tel1 = m_tel1;
	}
	public String getM_tel2() {
		return this.m_tel2;
	}
	public void setM_tel2(String m_tel2) {
		this.m_tel2 = m_tel2;
	}
	public String getM_tel3() {
		return this.m_tel3;
	}
	public void setM_tel3(String m_tel3) {
		this.m_tel3 = m_tel3;
	}
	public String getTel() {
		return this.m_tel1 + "-" + this.m_tel2 + "-" + this.m_tel3;
	}
	public void setTel(String tel) {
		this.tel = tel;
		if(tel != null && (tel.length() == 13 || tel.length() == 12) && tel.indexOf("-") > 0) {
			this.m_tel1 = tel.split("-")[0];
			this.m_tel2 = tel.split("-")[1];
			this.m_tel3 = tel.split("-")[2];
		}
	}
	public String getM_hp1() {
		return this.m_hp1;
	}
	public void setM_hp1(String m_hp1) {
		this.m_hp1 = m_hp1;
	}
	public String getM_hp2() {
		return this.m_hp2;
	}
	public void setM_hp2(String m_hp2) {
		this.m_hp2 = m_hp2;
	}
	public String getM_hp3() {
		return this.m_hp3;
	}
	public void setM_hp3(String m_hp3) {
		this.m_hp3 = m_hp3;
	}
	public String getHp() {
		return this.m_hp1 + "-" + this.m_hp2 + "-" + this.m_hp3;
	}
	public void setHp(String hp) {
		this.hp = hp;
		if(hp != null && hp.length() == 13 && hp.indexOf("-") > 0) {
			this.m_hp1 = hp.split("-")[0];
			this.m_hp2 = hp.split("-")[1];
			this.m_hp3 = hp.split("-")[2];
		}
	}
	public String getIntroduce() {
		return engToKor(this.introduce);
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public String getLocale() {
		return engToKor(this.locale);
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getM_zip1() {
		return this.m_zip1;
	}
	public void setM_zip1(String mzip1) {
		this.m_zip1 = mzip1;
	}
	public String getM_zip2() {
		return this.m_zip2;
	}
	public void setM_zip2(String mzip2) {
		this.m_zip2 = mzip2;
	}
	public String getZip() {
		return this.m_zip1 + "-" + this.m_zip2;
	}
	public void setZip(String zip) {
		this.zip = zip;
		if(zip != null && zip.length() == 7 && zip.indexOf("-") > 0) {
			this.m_zip1 = zip.split("-")[0];
			this.m_zip2 = zip.split("-")[1];			                          
		}
	}
	public String getM_addr1() {
		return this.m_addr1;
	}
	public void setM_addr1(String maddr1) {
		this.m_addr1 = maddr1;
	}
	public String getM_addr2() {
		return this.m_addr2;
	}
	public void setM_addr2(String maddr2) {
		this.m_addr2 = maddr2;
	}
	public int getNo() {
		return this.no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getM_id() {
		return this.m_id;
	}
	public void setM_id(String mid) {
		this.m_id = mid;
	}
	public String getM_pw() {
		return this.m_pw;
	}
	public void setM_pw(String mPw) {
		m_pw = mPw;
	}
	public String getM_name() {
		return this.m_name;
	}
	public void setM_name(String mname) {
		this.m_name = mname;
	}
	public String getM_jumin1() {
		return this.m_jumin1;
	}
	public void setM_jumin1(String mjumin1) {
		this.m_jumin1 = mjumin1;
	}
	public String getM_jumin2() {
		return this.m_jumin2;
	}
	public void setM_jumin2(String mjumin2) {
		this.m_jumin2 = mjumin2;
	}
	public String getM_email1() {
		return m_email1;
	}
	public void setM_email1(String mEmail1) {
		m_email1 = mEmail1;
	}
	public String getM_email2() {
		return m_email2;
	}
	public void setM_email2(String mEmail2) {
		m_email2 = mEmail2;
	}
	public String getJumin_number() {
		return this.m_jumin1 + "-" + this.m_jumin2;
		//return jumin_number;
	}
	public void setJumin_number(String jumin_number) {
		this.jumin_number = jumin_number;
		if(jumin_number != null && jumin_number.length() == 13 && jumin_number.indexOf("-") > 0) {
			this.m_jumin1 = jumin_number.split("-")[0];
			this.m_jumin2 = jumin_number.split("-")[1];
		}
	}
	public String getConfirm_use() {
		return this.confirm_use;
	}
	public void setConfirm_use(String confirm_use) {
		this.confirm_use = confirm_use;
	}
	public int getResult_value() {
		return this.result_value;
	}
	public void setResult_value(int result_value) {
		this.result_value = result_value;
	}
	public String getLevel() {
		return this.level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	public String engToKor(String str) {
		if(str == null || str.trim().equals("")) return str;
		try {
			str = new String(str.getBytes("ISO-8859-1"), "EUC-KR");
			return str;
		}catch(java.io.UnsupportedEncodingException uee) {
			return null;
		}
	}
}
