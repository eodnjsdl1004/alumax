package com.alumax.gw.controller.actionform;

import org.apache.struts.validator.ValidatorActionForm;

public class LoginActionForm extends ValidatorActionForm{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String m_id;
	private String m_pw;
	private String m_jumin1;
	private String m_jumin2;
	private String m_gubun;
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String mId) {
		m_id = mId;
	}
	public String getM_pw() {
		return m_pw;
	}
	public void setM_pw(String mPw) {
		m_pw = mPw;
	}
	public String getM_jumin1() {
		return m_jumin1;
	}
	public void setM_jumin1(String mJumin1) {
		m_jumin1 = mJumin1;
	}
	public String getM_jumin2() {
		return m_jumin2;
	}
	public void setM_jumin2(String mJumin2) {
		m_jumin2 = mJumin2;
	}
	public String getM_gubun() {
		return m_gubun;
	}
	public void setM_gubun(String mGubun) {
		m_gubun = mGubun;
	}

}