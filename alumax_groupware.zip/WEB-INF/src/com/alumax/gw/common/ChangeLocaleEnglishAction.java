package com.alumax.gw.common;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.Globals;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ChangeLocaleEnglishAction extends Action{
	private Log log = LogFactory.getLog(ChangeLocaleEnglishAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		HttpSession session = request.getSession();
		log.info("Locale => "+session.getAttribute("org.apache.struts.action.LOCALE"));
		
		Locale locale =new Locale("en","");
		session.setAttribute(Globals.LOCALE_KEY, locale);
		
		return mapping.findForward("locale_english");
		
	}
}
