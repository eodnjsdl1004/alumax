package com.alumax.gw.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.alumax.gw.model.dto.UserDTO;

public class LoginCheckFilter implements Filter{
	private Log log = LogFactory.getLog(LoginCheckFilter.class);

	private ArrayList<String> nocheckList= new ArrayList<String>();

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest hrequest = (HttpServletRequest)request;
		HttpServletResponse hresponse = (HttpServletResponse)response;
		
		String contextPath = hrequest.getContextPath();
		String requestURL = hrequest.getRequestURI().toString();
		log.info("requestURL :"+requestURL);
		HttpSession session = hrequest.getSession();
		ActionMessages message = new ActionMessages();

		/*
		* ���ӵ����ο� ���� ����� ������ ����
		* kr.localhost.com => ko ���� ����.
		* en.localhost.com => en ���� ����.
		* hosts file�� �����μ��� �� �׽�Ʈ
		*/
/*		
  		log.info("servername : "+hrequest.getServerName());
		Locale locale=null;
		if(hrequest.getServerName()=="en.localhost.com"){
			locale =new Locale("en","");
		}else{
			locale =new Locale("ko","");
		}
		log.info("setLocale : "+locale);
		session.setAttribute("org.apache.struts.action.LOCALE", locale);
*/		
		boolean needLogin = true;
		for(int i=0;i<nocheckList.size();i++){
			String fullPath = contextPath + (String)nocheckList.get(i);
			if(requestURL.indexOf(fullPath)!=-1){
				needLogin = false;
			}
		}
		
		if(needLogin){
			if(requestURL.indexOf("/admin/")!=-1){
				UserDTO user = (UserDTO)session.getAttribute("admin_user");
				if(user==null || !user.isLogin()){
					hresponse.sendRedirect(contextPath + "/admin/login.do");
					return;
				}
			}else{
				UserDTO user = (UserDTO)session.getAttribute("user");
				if(user==null || !user.isLogin()){
					Map map = request.getParameterMap();
					Iterator it = map.keySet().iterator();
					Object key = null;
					String[] value = null;
					String request_param = "";
					
					while(it.hasNext()){
					    key = it.next();
					    value = (String[]) map.get(key);
					    for(int i=0 ; i < value.length; i++){
//					    	log.info("i : "+i);
//					    	log.info("key : "+key);
//					    	log.info("value : "+value[i]);
					    	request_param += key+"="+value[i]+"&";
					    }
					}
			    	log.info("request_param : "+request_param);

					session.setAttribute("return_url", requestURL+"?"+request_param);
					message.add("research.success", new ActionMessage("msg.research.join.success",true));
					session.setAttribute("message", "�α����� ���ּ���");
					hresponse.sendRedirect(contextPath + "/user/l_login.do");
					return;
				}
			}
		}
		
		chain.doFilter(request, response);
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		String nocheck = filterConfig.getInitParameter("nocheck");
		StringTokenizer st = new StringTokenizer(nocheck,",");
		while(st.hasMoreTokens()){
			String path = st.nextToken().trim();
			nocheckList.add(path);
		}
	}
	
}
