package com.alumax.gw.common;

import java.io.*;
import java.text.*;

/**
 *	@(#) Utility.java
 *	String�� ������ ���� ��ƿ��Ƽ ����
 *
 *	@author  ggwangs
 *	@last_update_date  2001.06.23
 */
public class Utility
{
	/**
	 *	nullCheck
	 *	@param String str
	 *	@param String val
	 *	@return String
	 */
	public static String nullCheck( String str )
	{
		String ret = null;
		if (str==null) ret = "";
		else ret = str;
		return ret;
	} 

	/**
	 *	nullCheck
	 *	@param String str
	 *	@param String val
	 *	@return String
	 */
	public static String nullCheck( String str, String val )
	{
		String ret = null;
		if (str==null || str.equals("")) ret = val;
		else ret = str;
		return ret;
	} 

	/**
	 *	unicode -> kor code
	 *	Exception�ÿ� ��ȯ���� ���� raw str�� ����
	 *	@param String str
	 *	@return String
	 */
	public static String e2k( String str )
	{
		String ret = str;
		try {
			ret = new String(str.getBytes("8859_1"), "KSC5601");
		} catch( UnsupportedEncodingException e ) {}
		return ret;
	} 

	/**
	 *	kor code -> unicode
	 *	Exception�ÿ� ��ȯ���� ���� raw str�� ����
	 *	@param String str
	 *	@return String
	 */
	public static String k2e( String str )
	{
		String ret = str;
		try {
			ret = new String(str.getBytes("KSC5601"), "8859_1");
		} catch( UnsupportedEncodingException e ) {}
		return ret;
	} 

	/**
	 *	��ҹ��� ignore�� ���� str1�ȿ� str2�� ��ġ���� ����
	 *	@param boolean ignore
	 *	@param String str1
	 *	@param String str2
	 *	@return int
	 *
	 *	@sample Utility.indexOf( true,"efgefg","FG" )
	 */
	public static int indexOf( boolean ignore, String str1, String str2 )
	{
		return indexOf( ignore,str1,0,str2 );
	}

	/**
	 *	��ҹ��� ignore�� ���� str1.substring(off)�ȿ� str2�� ��ġ��������
	 *	@param boolean ignore
	 *	@param String str1
	 *	@param int off
	 *	@param String str2
	 *	@return int
	 *
	 *	@sample Utility.indexOf( true,"efgefg",2,"EF" )
	 */
	public static int indexOf( boolean ignore, String str1, int off, String str2 )
	{
		if( !ignore ) return str1.indexOf(str2,off);

		int len1 = str1.length();
		int len2 = str2.length();
		if( len1<len2 ) return -1;

		int pos = -1;
		for( int i=off; i<=len1-len2; i++)
		{
			if( str1.regionMatches( ignore,i,str2,0,len2 ) )
			{
				pos = i; break;
			}
		}
		return pos;
	}

	/**
	 *	��ҹ��� ignore�� ���� str1�ȿ� ������ str2�� ��ġ��������
	 *	@param boolean ignore
	 *	@param String str1
	 *	@param String str2
	 *	@return int
	 *
	 *	@sample Utility.lastIndexOf( true,"abcdefgefg","EF" )
	 */
	public static int lastIndexOf( boolean ignore, String str1, String str2 )
	{
		if( !ignore ) return str1.lastIndexOf(str2);

		int len1 = str1.length();
		int len2 = str2.length();
		if( len1<len2 ) return -1;

		int pos = -1;
		for( int i=len1-len2; i>=0; i--)
		{
			if( str1.regionMatches( ignore,i,str2,0,len2 ) )
			{
				pos = i; break;
			}
		}
		return pos;
	}

	/**
	 *	��ҹ��� ignore�� ���� str1�� str2�� �����ϴ����� ����
	 *	@param boolean ignore
	 *	@param String str1
	 *	@param String str2
	 *	@return boolean
	 *
	 *	@sample Utility.startsWith( true,"abcdefg","ABC" )
	 */
	public static boolean startsWith( boolean ignore, String str1, String str2 )
	{
		return startsWith( ignore,str1,0,str2 );
	}

	/**
	 *	��ҹ��� ignore�� ���� str1.substring(off)�� str2�� �����ϴ����� ����
	 *	@param boolean ignore
	 *	@param String str1
	 *	@param int off
	 *	@param String str2
	 *	@return boolean
	 *
	 *	@sample Utility.startsWith( true,"abcdefg",2,"CD" )
	 */
	public static boolean startsWith( boolean ignore, String str1, int off, String str2 )
	{
		if( !ignore ) return str1.startsWith( str2,off );

		if( off==indexOf(ignore,str1,off,str2) ) return true;
		else return false;
	}

	/**
	 *	String�� left trim
	 *	@param String str
	 *	@return String
	 *
	 *	@sample Utility.ltrim( "   ������" )
	 */
	public static String ltrim( String str )
	{
		int start;
		for( start=0; start<str.length(); start++ )
		{
			if( str.charAt(start)!=' ' ) break;
		}
		return str.substring( start );
	}

	/**
	 *	String�� right trim
	 *	@param String str
	 *	@return String
	 *
	 *	@sample Utility.rtrim( "������  " )
	 */
	public static String rtrim( String str )
	{
		int end;
		for( end=str.length()-1; end>=0; end-- )
		{
			if( str.charAt(end)!=' ' ) break;
		}
		return str.substring( 0,end+1 );
	}

	/**
	 *	str1���� �ִ� str2�� replace�� ��ü
	 *	@param String str1
	 *	@param String str2
	 *	@param String replace
	 *	@return String
	 *
	 *	@sample Utility.replace( "�����ٶ󰡳��ٶ�","����","ABC" )
	 */
	public static String replace( String str1, String str2, String replace )
	{
		return replace( str1,0,str2,replace );
	}

	/**
	 *	str1�� off index���Ŀ� �ִ� str2�� replace�� ��ü
	 *	@param String str1
	 *	@param int off
	 *	@param String str2
	 *	@param String replace
	 *	@return String
	 *
	 *	@sample Utility.replace( "�����ٶ󰡳��ٶ�",3,"����","ABC" )
	 */
	public static String replace( String str1, int off, String str2, String replace )
	{
		off = str1.indexOf( str2,off );
		StringBuffer buff = new StringBuffer( str1 );
		while( off!=-1 )
		{
			buff.replace( off,off+str2.length(),replace );
			str1 = buff.toString();
			if( off+str2.length() < str1.length() )
				off = str1.indexOf( str2,off+str2.length()+1 );
			else off = -1;
		}
		return str1;
	}

	/**
	 *	str�� ������ ��ġ�� replace�� ��ü
	 *	@param String str
	 *	@param int off
	 *	@param int len
	 *	@param String replace
	 *	@return String
	 *
	 *	@sample Utility.replace( "�����ٶ󰡳��ٶ�",3,2,"ABC" )
	 */
	//@SuppressWarnings("unused")
	private static String replace( String str, int off, int len, String replace )
	{
		StringBuffer buff = new StringBuffer( str );
		buff.replace( off,off+len,replace );
		return buff.toString();
	}

	/**
	 *	�Էµ� ��Ʈ�����κ��� ���ڸ� �ɷ��� ����
	 *	@param String str
	 *	@return String
	 *
	 *	@sample Utility.getDigitString( "32sadf4234" )
	 */
	public static String getDigitString( String str )
	{
		StringBuffer buff = new StringBuffer();
		char[] ch = str.toCharArray();
		for( int i=0; i<ch.length; i++ )
		{
			if( Character.isDigit(ch[i]) )
				buff.append( ch[i] );
		}
		return buff.toString();
	}

	/**
	 *	��Ʈ���� ��� ���ڷ� �Ǿ��ִ��� üũ
	 *	@param String str
	 *	@return boolean
	 *
	 *	@sample Utility.isDigit( "324234" )
	 */
	public static boolean isDigit( String str )
	{
		char[] ch = str.toCharArray();
		for( int i=0; i<ch.length; i++ )
		{
			if( !Character.isDigit(ch[i]) )
				return false;
		}
		return true;
	}



   //���ڸ� �ݾ�ǥ�ù����� ���� ex)1234560 -> 1,234,560
    public static String commaFormat(int amount_p) {
        String strAmount = new Integer(amount_p).toString();
        return commaFormat(strAmount);
    }


    public static String commaFormat(long amount_p) {
        String strAmount = new Long(amount_p).toString();
        return commaFormat(strAmount);
    }

	public static String commaFormat(float amount_p) {
        String strAmount = new Float(amount_p).toString();
        return commaFormat(strAmount);
    }



    public static String commaFormat(double amount_p) {
        String strAmount = new Double(amount_p).toString();
        return commaFormat(strAmount);
    }



    public static String commaFormat(String amount_p) {
        if(amount_p == null || (amount_p.trim()).equals("")) {
            return "0";
        } else {
            if(amount_p.indexOf(".") == -1) {
                DecimalFormat df = new DecimalFormat("###,###"); 
                return df.format(Long.parseLong(amount_p)).toString(); 
            } else {
                return commaFormat(amount_p,amount_p.length()-(amount_p.indexOf(".")+1));
            }
        }
    }

    public static String commaFormat(String amount_p, int sosu_size) {
        if(amount_p == null || (amount_p.trim()).equals("")) {
            return "0";
        } else {
			String f = ".";
			for(int i=0;i<sosu_size;i++) f += "0";
			f = f + "#";
			 DecimalFormat df = new DecimalFormat("###,###"+f); 
			 return df.format(Double.parseDouble(amount_p)).toString();
		}
    }


	/**
	 *	���� �ش� �������� ��ȯ�Ͽ� ����
	 *	������ "###,##0"���� ����
	 *	@param long num
	 *	@return String
	 *
	 *	@sample Utility.getDigitPattern( 324234 )
	 */
	public static String getDigitPattern( long num )
	{
		return getDigitPattern( num,"###,##0" );
	}

	/**
	 *	���� �ش� �������� ��ȯ�Ͽ� ����
	 *	@param long num
	 *	@param String pattern
	 *	@return String
	 *
	 *	@sample Utility.getDigitPattern( 324234,"#0,##" )
	 */
	public static String getDigitPattern( long num, String pattern )
	{
		DecimalFormat df = new DecimalFormat(pattern);
		return df.format(num).toString();
	}

	
	/**
	 *	String ���� �ش� �������� ��ȯ�Ͽ� ����
	 *	������ "##0.000"���� ����
	 *	@param String dNum
	 *	@return String
	 *
	 *	@sample Utility.getDigitPattern( "324.234" )
	 */
	public static String getDigitPattern( String dNum )
	{
		double d = 0;
		try {
			d = Double.parseDouble( dNum );
		} catch( Exception e ) {}

		return getDigitPattern( d,"##0.000" );
	}

	/**
	 *	String ���� �ش� �������� ��ȯ�Ͽ� ����
	 *	@param String dNum
	 *	@param String pattern
	 *	@return String
	 *
	 *	@sample Utility.getDigitPattern( "324","###,##0" )
	 */
	public static String getDigitPattern( String num, String pattern )
	{
		double d = 0;
		try {
			d = Double.parseDouble( num );
		} catch( Exception e ) {}

		return getDigitPattern( d,pattern );
	}

	/**
	 *	���� �ش� �������� ��ȯ�Ͽ� ����
	 *	������ "##0.000"���� ����
	 *	@param double num
	 *	@param String pattern
	 *	@return String
	 *
	 *	@sample Utility.getDigitPattern( 324.234 )
	 */
	public static String getDigitPattern( double num )
	{
		return getDigitPattern( num,"##0.000" );
	}
	
	

	/**
	 *	���� �ش� �������� ��ȯ�Ͽ� ����
	 *	@param double num
	 *	@param String pattern
	 *	@return String
	 *
	 *	@sample Utility.getDigitPattern( 324.234,"#0.##" )
	 */
	public static String getDigitPattern( double num, String pattern )
	{
		DecimalFormat df = new DecimalFormat( pattern );
		return df.format(num).toString();
	}


	/**
	 *	��Ʈ���� �ش� ����(len)��ŭ �߶� ����
	 *	���� ��Ʈ���� ���̰� len���� ������ �ڽ��� ����
	 *	@param String str
	 *	@param int len
	 *	@return String
	 *
	 *	@sample Utility.fixLength( "�����ٶ󸶹ٻ�",3 )
	 */
	public static String fixLength( String str, int len )
	{
		return fixLength( str,0,len );
	}

	/**
	 *	��Ʈ��(str)�� off���� �ش� ����(len)��ŭ �߶� ����
	 *	���� (str.length()-off)�� len���� ������ str.substring(off)�� ����
	 *	off�� len�� �߸� �����ÿ� ""�� ����
	 *	@param String str
	 *	@param int off
	 *	@param int len
	 *	@return String
	 *
	 *	@sample Utility.fixLength( "�����ٶ󸶹ٻ�",2,3 )
	 */
	public static String fixLength( String str, int off, int len )
	{
		int str_len = str.length();
		if( str_len<=off || len<=0 ) return "";
		if( str_len-off<len ) return str.substring(off);

		return str.substring( off,len+off );
	}

	/**
	 *	��Ʈ���� �ش� ����Ʈ����(len)��ŭ �߶� ����
	 *	@param String str
	 *	@param int len
	 *	@return String
	 * @throws UnsupportedEncodingException 
	 */

	public synchronized static String fixByteLength( String str, int byteSize ) throws UnsupportedEncodingException
	{
		return fixByteLength(str, byteSize, "");
	}

	/**
	 *	��Ʈ���� �ش� ����Ʈ����(len)��ŭ �߶� ����
	 *	@param String str
	 *	@param int len
	 *	@return String
	 * @throws UnsupportedEncodingException 
	 */

	public synchronized static String fixByteLength( String str, int byteSize , String tail) throws UnsupportedEncodingException
	{
		int rSize = 0;
		int len = 0;
		if(str.getBytes("EUC-KR").length>byteSize){

			for(;rSize<str.length();rSize++){
				if(str.charAt(rSize)>0x007F){
					len +=2;
				}
				else {
					len++;
				}
				if(len>byteSize){
					break;
				}
			}
			str = str.substring(0,rSize)+tail;
		}
		return str;

	}	

	/**
	 *	obyte�� dbyte�� ��ģ �迭�� ����
	 *	@param byte[] obyte
	 *	@param byte[] dbyte
	 *	@return byte[]
	 */
	public static byte[] appendByte( byte[] obyte, byte[] dbyte )
	{
		byte[] nbyte = null;
		if( obyte==null )
		{
			if ( dbyte==null ) return null;

			nbyte = new byte[dbyte.length];
			System.arraycopy( dbyte,0,nbyte,0,dbyte.length );
			return nbyte;
		}

		return appendByte(obyte,dbyte,dbyte.length);
	}

	/**
	 *	obyte�� dbyte�� ��ģ �迭�� ����
	 *	@param byte[] obyte
	 *	@param byte[] dbyte
	 *	@param int dlen
	 *	@return byte[]
	 */
	public static byte[] appendByte( byte[] obyte, byte[] dbyte, int dlen )
	{
		byte[] nbyte = null;
		if( obyte==null )
		{
			if ( dbyte==null ) return null;
			nbyte = new byte[dlen];
			System.arraycopy( dbyte,0,nbyte,0,dlen );
			return nbyte;
		}

		int olen = obyte.length;
		int nlen = olen+dlen;
		nbyte = new byte[nlen];
		System.arraycopy( obyte,0,nbyte,0,olen );
		System.arraycopy( dbyte,0,nbyte,olen,dlen );

		return nbyte;
	}


	public static int getInt(byte[] bt){
		int temp=0;
		int[] bt2 = new int[4];
		for(int i = 0;i<4;i++){
			bt2[i]=bt[i]<0?(Byte.MAX_VALUE+1)*2+bt[i]:bt[i];
			temp |=bt2[i]<<8*(3-i);
		}
		return temp;
	}

	//	  int -> byte[]
	public static byte[] intToByteArr(int i)
	{
		return new byte[] { (byte)(i >> 24), (byte)(i >> 16), (byte)(i >> 8), (byte)i };
	}
	//	  byte[] -> int
	public static int byteArrToint(byte[] b)
	{
		return b[0] << 24 | (b[1] & 0xff) << 16 | (b[2] & 0xff) << 8 | (b[3] & 0xff);
	}
	public static int swabInt(int v){
		return(v>>>24)|(v<<24)|((v<<8)&0x00FF0000)|((v>>8)&0x0000FF00);
	}

	/**
	 *	Throwable(Exception�� ���� Ŭ����)�� stackTrace view
	 *	@param Throwable e
	 *	@return String
	 *
	 *	@sample Utility.getStackTrace( new Exception() )
	 */
	public static String getStackTrace( Throwable e )
	{
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		PrintWriter writer = new PrintWriter(bytes, true);
		e.printStackTrace(writer);

		return bytes.toString();
	}
	
	 /**
	  * ���� : ���� ������ ��θ� ���Ѵ�.
	  * @author 20060329 teja �߰�
	  * @param String file_name :: web ��� + ���ϸ�  
	  * @return String full_filename :: ���� ��ο� ���ϸ�  
	  */
	 public static String getLocalpath(String file_name) {

	 	String full_filename = "";
		//file_name = "CommonUtil.class";
	 	Utility com = new Utility();
		
		try{				
				if(file_name.substring(  file_name.length()-6,  file_name.length() ).equals(".class")){
					full_filename  = com.getClass().getResource( file_name ).getPath().toString();
				}else{
					java.net.URL url = com.getClass().getResource( file_name );
					full_filename = url.getPath().toString();
				}
		}catch(Exception ex){
				//ex.printStackTrace();
				full_filename = "��ο� ���ϸ��� Ȯ�����ּ���";
		}
		
		return full_filename;
	 }

	 public static String removeTag(String s) {
			if (s == null)
				return "";
				
	        final int NORMAL_STATE = 0;
	        final int TAG_STATE = 1;
	        final int START_TAG_STATE = 2;
	        final int END_TAG_STATE = 3;
	        final int SINGLE_QUOT_STATE = 4;
	        final int DOUBLE_QUOT_STATE = 5;
	        int state = NORMAL_STATE;
	        int oldState = NORMAL_STATE;
	        char[] chars = s.toCharArray();
	        StringBuffer sb = new StringBuffer();
	        char a;
	        for (int i = 0; i < chars.length; i++) {
	            a = chars[i];
	            switch (state) {
	                case NORMAL_STATE:
	                    if (a == '<')
	                        state = TAG_STATE;
	                    else
	                        sb.append(a);
	                    break;
	                case TAG_STATE:
	                    if (a == '>')
	                        state = NORMAL_STATE;
	                    else if (a == '\"') {
	                        oldState = state;
	                        state = DOUBLE_QUOT_STATE;
	                    }
	                    else if (a == '\'') {
	                        oldState = state;
	                        state = SINGLE_QUOT_STATE;
	                    }
	                    else if (a == '/')
	                        state = END_TAG_STATE;
	                    else if (a != ' ' && a != '\t' && a != '\n' && a != '\r' && a != '\f')
	                        state = START_TAG_STATE;
	                    break;
	                case START_TAG_STATE:
	                case END_TAG_STATE:
	                    if (a == '>')
	                        state = NORMAL_STATE;
	                    else if (a == '\"') {
	                        oldState = state;
	                        state = DOUBLE_QUOT_STATE;
	                    }
	                    else if (a == '\'') {
	                        oldState = state;
	                        state = SINGLE_QUOT_STATE;
	                    }
	                    else if (a == '\"')
	                        state = DOUBLE_QUOT_STATE;
	                    else if (a == '\'')
	                        state = SINGLE_QUOT_STATE;
	                    break;
	                case DOUBLE_QUOT_STATE:
	                    if (a == '\"')
	                        state = oldState;
	                    break;
	                case SINGLE_QUOT_STATE:
	                    if (a == '\'')
	                        state = oldState;
	                    break;
	            }
	        }
	        return sb.toString();
	    }



}
