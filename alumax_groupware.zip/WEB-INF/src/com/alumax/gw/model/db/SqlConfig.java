package com.alumax.gw.model.db;

import java.io.Reader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;


public class SqlConfig {
	private static SqlMapClient sqlMap = null;
	private static SqlConfig instance_ = null;
	
	private static Log log =  LogFactory.getLog(SqlConfig.class);
	
	private SqlConfig() throws Exception {
		Reader reader = null;
		String resource ="SqlMapConfig.xml";
		try {
			if (sqlMap == null) {
				
				reader = Resources.getResourceAsReader(resource);
				sqlMap = SqlMapClientBuilder.buildSqlMapClient(reader);
				reader.close();
			}
		} catch (Exception e) {
			if(log.isInfoEnabled()){
				log.info("Exception : "+ e);
			}
			throw e;
		} finally {
			if (reader != null)
				 reader.close();
			reader = null;
		}
	}
	
	 public static SqlConfig instance(){
		 try {
			 if (instance_ == null) {
				 synchronized (SqlConfig.class) {
					 if (instance_ == null)
						 instance_ = new SqlConfig();
						if(log.isInfoEnabled()){
							log.info("SqlConfig instance create! ");
						}
					 
				 }
			 }
			 
		 } catch (Exception e) {
				if(log.isInfoEnabled()){
					log.info("Exception : "+ e);
				}
		 }
		 return instance_;
	 }
	 
	 public SqlMapClient getSqlMapInstance() {
			if(log.isInfoEnabled()){
				log.info("SqlMapClient instance create! ");
			}
		 return sqlMap;
	 }
}
