package com.alumax.gw.model.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alumax.gw.model.db.SqlConfig;
import com.alumax.gw.model.dto.MemberDTO;
import com.ibatis.sqlmap.client.SqlMapClient;


public class MemberDAO implements DataAccessObject{
	
	private static Log log = LogFactory.getLog(MemberDAO.class);
	private SqlMapClient smc = SqlConfig.instance().getSqlMapInstance();

	public MemberDAO(){
		if(log.isInfoEnabled()){
			log.info("MemberDAO ��ü����");
		}
	}
	
	public Object insert(Object key, String condition) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public int update(long bno) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	public long count(String condition) throws Exception {
		Long result = (Long)smc.queryForObject("getMemberCount");
		return result;
	}

	public long count(Object key) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	public long count(Object key, String condition) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	public int delete(Object key, String condition) throws Exception {
		String m_id = (String)key;
		int result = 0;
		smc.startTransaction();
		try{
			result = smc.delete("deleteMemberBaseInfo", m_id);
			
			if(result == 1)
				smc.commitTransaction();
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			smc.endTransaction();
		}
		
		return result;
	}

	public Object insert(Object dto) throws Exception {
		MemberDTO memberDTO=(MemberDTO)dto;
		return smc.insert("insertUser",memberDTO);
	}

	public List select(long rowsPerPage, long currentPage, String condition,
			String order) throws Exception {
		int end = (int)currentPage * (int)rowsPerPage;
		int start = (((int)currentPage - 1) * (int)rowsPerPage)+1;
		
		HashMap map = new HashMap();
		map.put("end",end);
		map.put("start", start);
		
		List<MemberDTO> result = new ArrayList<MemberDTO>();
//		MemberDTO memberDTO = new MemberDTO();
		if("all".equals(condition))
			result = (List<MemberDTO>)smc.queryForList("getMemberList", map);
		else if("admin".equals(condition))
			result = (List<MemberDTO>)smc.queryForList("getAdminMemberList");

/*		Iterator<MemberDTO> iter = result.iterator();
		  while (iter.hasNext()) {
			  MemberDTO data = iter.next();
			  log.info("data.getId():"+data.getId());
			  log.info("data.getName():"+data.getName());
			  log.info("data.getEmail():"+data.getEmail());
		  }
*/
		  
		return result;
	}

	public Object select(Object key) throws Exception {
		MemberDTO memberDTO=null;
		try{
			String no = (String)key;
			memberDTO = (MemberDTO)smc.queryForObject("getMemberResultMap",no);
			if(memberDTO != null && log.isInfoEnabled()){
				log.info("getM_id :"+memberDTO.getM_id());
				log.info("getM_pw :"+memberDTO.getM_pw());
				log.info("getM_name :"+memberDTO.getM_name());
				log.info("getM_email :"+memberDTO.getM_email1());
				log.info("getM_email :"+memberDTO.getM_email2());
				log.info("getM_jumin1 :"+memberDTO.getM_jumin());
				log.info("getM_jumin1 :"+memberDTO.getM_jumin1());
				log.info("getM_jumin2 :"+memberDTO.getM_jumin2());
			}
			return memberDTO;
			
		}catch(Exception e){
			e.printStackTrace();
			log.error("exception :"+e.toString());
			return null;
		}
	}

	public List select(Object key, String condition) throws Exception {
		//MemberDTO memberDTO=(MemberDTO)key;
		log.info("condition:"+condition);
		try{
			List<MemberDTO> result = new ArrayList<MemberDTO>();
			if("search".equals(condition)) {
				result = (List<MemberDTO>)smc.queryForList("getFindMemberResult", key);
			}else if("id".equals(condition)){
				result = (List<MemberDTO>)smc.queryForList("getFindIdResultMap", (MemberDTO)key);
			}else if("password".equals(condition)){
				result = (List<MemberDTO>)smc.queryForList("getFindPasswordResultMap", (MemberDTO)key);
			}else if("admin_login".equals(condition)){
				result = (List<MemberDTO>)smc.queryForList("getAdminLoginCheckResultMap", (MemberDTO)key);
			}else{
			    log.info("login");
				result = (List<MemberDTO>)smc.queryForList("getLoginResultMap", (MemberDTO)key);
			}
			
			Iterator<MemberDTO> iter = result.iterator();
			while (iter.hasNext()) {
				  MemberDTO data = iter.next();
				  log.info("getM_id():"+data.getM_id());
				  log.info("getM_pw():"+data.getM_pw());
				  log.info("getM_name():"+data.getM_name());
				  log.info("getM_email():"+data.getM_email1());
				  log.info("getM_email():"+data.getM_email2());
//				  log.info("getM_jumin():"+data.getM_jumin());
			}

			return result;
			
		}catch(Exception e){
			e.printStackTrace();
			log.error("exception :"+e.toString());
			return null;
		}
	}

	public int update(Object dto) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	public int update(Object dto, String gubun) throws Exception {
		MemberDTO memberDTO=(MemberDTO)dto;
		int result = 0;
		smc.startTransaction();
		try{
			if("update".equals(gubun)){												
				result = smc.update("updateUser",memberDTO);
			}else{
				return 0;
			}
			log.info("update result:"+result);
			if(result==1){
				smc.commitTransaction();
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			smc.endTransaction();
		}
		
		return result;
	}
	
}
