package com.alumax.gw.model.dao;

import java.util.List;

public interface DataAccessObject {
	
	Object insert(Object dto) throws Exception;
	
	Object insert(Object key,String condition) throws Exception;
	
	int update(Object dto) throws Exception;
	
	int update(Object key, String gubun) throws Exception;
	
	int update(long bno) throws Exception;
	
	int delete(Object key, String condition) throws Exception;
	
	Object select(Object key) throws Exception;

	List select(Object key,String condition) throws Exception;

	List select(long rowsPerPage, long currentPage, String condition, String order) throws Exception;
	
	long count(String condition) throws Exception;
	
	long count(Object key) throws Exception;

	long count(Object key, String condition) throws Exception;
}
