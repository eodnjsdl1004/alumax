document.write('<table width=1026  height="605" align=center><tr>');
document.write('<td>');
document.write('<object classid=clsid:3543897F-577B-4371-99E6-20EC4FA31A4F id=View1 width=1023 height=605 align=left ');
document.write('codebase="http://www.my-builder.co.kr/demo/2008/Biin/MyBuilderViewer.cab#version=6,2,1,2"></object>');
document.write('</td></tr></table>');


