window.YB_Loader = {
  Version: '1.0.0',
  require: function(libraryName) {
    // inserting via DOM fails in Safari 2.0, so brute force approach
    document.write('<script type="text/javascript" src="'+libraryName+'"></script>');
  },
  init: function() {
    if((typeof Prototype=='undefined') || 
       (typeof Element == 'undefined') || 
       (typeof Element.Methods=='undefined') ||
       parseFloat(Prototype.Version.split(".")[0] + "." +
                  Prototype.Version.split(".")[1]) < 1.5)
       throw("yb_loader requires the Prototype JavaScript framework >= 1.5.0");
    
    $A(document.getElementsByTagName("script")).findAll( function(s) {
      return (s.src && s.src.match(/yb_loader\.js(\?.*)?$/))
    }).each( function(s) {
      var path = s.src.replace(/yb_loader\.js(\?.*)?$/,'');
      var includes = s.src.match(/\?.*load=([a-z,]*)/);
      (includes ? includes[1] : 'validator,util,cookie,form').split(',').each(
       function(include) { YB_Loader.require(path+'yb_'+include+'.js') });
    });
  },
  do_callback: function(i, r) {
    if($(i) && $(i).callback) { $(i).callback.call(null, r); }
  },
  yb_popup: function(u) {
    return window.open(u, '_blank', "directories=no,location=no,menubar=no,resizable=yes,scrollbars=no,status=no,width=300,height=200", true);
  },
  dialog: function(u) {
    //return window.showModelessDialog('dialog.html?'+u, window, "center:yes;help:no;edge:sunken;resizable:yes");
    return window.showModalDialog(u, window, "center:yes;help:no;edge:sunken;resizable:yes");
  },
  set_url: function(u) {
    $('yb_page').yb_url = u;
  },
  yb_reload: function() {
    this.set_page($('yb_page').yb_url);
  },
  set_menu: function(n) {
    this.set_div(n, 'yb_menu');
  },
  set_page: function(n) {
    this.set_div(n, 'yb_page');
  },
  call_page: function(u) {
    location.href = u;
  },
  reload_div: function(m) {
    yb_reload_div(m);
  },
  set_div: function(n, m) {
    yb_set_div(n, m);
  }
}
YB_Loader.init();
