function yb_form_option_select(f, o) {
  if(!f || !f.options) { return; }
  for(i = 0; i < f.options.length; i++) {
    f.options[i].selected = (f.options[i].value == ''+o);
  }
}
function yb_popup(u, n, w, h) {
  return window.open(u, n?n:'yb_popup', "directories=no,location=no,menubar=no,resizable=yes,scrollbars=yes,status=no,width="+(w?w:800)+",height="+(h?h:400), true);
}
function yb_popup_fix(u, n, w, h) {
  return window.open(u, n?n:'yb_popup', "directories=no,location=no,menubar=no,resizable=no,scrollbars=no,status=no,width="+(w?w:800)+",height="+(h?h:400), true);
}

function yb_dialog(u) {
  return window.showModalDialog(u, window, "center:yes;help:no;edge:sunken;resizable:yes");
}

function yb_link(u) {
  top.location.href=u;
}

function yb_action(u) {
  top.action_frame.location.href=u;
}

function yb_reload_div(m) {
  if(!m || !$(m).yb_reload) { return; }
  $(m).yb_reload();
}

function yb_set_div(n, m) {
  if(!m) { return; }
  $(m).yb_url = n;
  $(m).yb_reload = function() { yb_set_div(this.yb_url, this); }
  new Ajax.Updater(
    m,
    n,
    { method: 'get', evalScripts: 'true', asynchronous: 'true' }
  );
}

function yb_resizeWin(w, h, t) {
  if(!t) t = window;
  if(w > 1000) { w = 100; }
  if(h > 730) { h = 730; }
  if(t.dialogArguments) {
    t.dialogWidth = w+'px';
    t.dialogHeight = h+'px';
  } else {
    t.resizeTo(w, h);
  }
}

function yb_zoom_image(o) {
  //var zw=window.open('/cs/common/zoom.aspx?i='+o,'zw','directories=no,location=no,menubar=no,resizable=yes,scrollbars=yes,status=no,width=300,height=200');
  //var zw=yb_popup('','zw','directories=no,location=no,menubar=no,resizable=yes,scrollbars=yes,status=no,width=300,height=200');
  var zw=yb_popup('/cs/common/zoom.aspx?i='+o,'zw','directories=no,location=no,menubar=no,resizable=yes,scrollbars=no,status=no,width=300,height=200');
  return;

  zw.document.write(
    '<html><head><title>Image</title>' +
    '</head><body style="margin: 0;" onload="self.focus();">' +
    '<img src="'+o+'" style="cursor: pointer"' +
    ' onclick="self.close();"'+
    ' onload="window.resizeTo((this.width>800)?800:this.width+30, (this.height>700)?700:this.height+60)">'+
    '</body></html>');
  zw.document.close();
}

function yb_print_image(o) {
  //var zw=window.open('','zw','directories=no,location=no,menubar=no,resizable=yes,scrollbars=yes,status=no,width=300,height=200');
  //var zw=yb_popup('','zw','directories=no,location=no,menubar=no,resizable=yes,scrollbars=yes,status=no,width=300,height=200');
  var zw=yb_popup('/cs/common/zoom.aspx?p=y&i='+o,'zw','directories=no,location=no,menubar=no,resizable=yes,scrollbars=no,status=no,width=300,height=200');
  return;

  zw.document.write(
    '<html><head><title>Image</title>' +
    '</head><body style="margin: 0;" onload="self.focus();">' +
    '<img src="'+o+'" style="cursor: pointer"' +
    ' onclick="self.close();"'+
    ' onload="window.resizeTo((this.width>800)?800:this.width+30, (this.height>700)?700:this.height+60)">'+
    '</body></html>');
  zw.document.close();
  zw.print(zw.location.reload());
  zw.close();
}

function yb_set_zoom_image(s, p) {
  var e = $(s);
  $A(e.getElementsByTagName('img')).findAll(
    function(s) {
      return (s.src && s.src.match(p?p:/view.aspx\?fu=/));
    }
  ).each(
    function(s) {
      s.onclick=function() { yb_zoom_image(this.src); };
      s.style.cursor='pointer';
    }
  );
}

function yb_confirm(u, m, t){
  if(confirm(m)){
    eval(t).location.href = u;
  }
  return false;
}

function yb_flash(url, width, height){
	document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="' + width + '" height="' + height + '" VIEWASTEXT>');
	document.write('<param name="movie" value="' + url + '">');
	document.write('<param name="quality" value="high">');
	document.write('<param name="wmode" value="transparent">');
	document.write('<param name="menu" value="false">');
	document.write('<embed src="' + url + '" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="' + width + '" height="' + height + '"></embed>');
	document.write('</object>');
}
