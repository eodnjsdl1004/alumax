var Validator = {
  is_empty: function() { return (this.length == 0 || this.match(/^\s+$/) != null); },
  is_email: function() { return (this.match(/^[_a-zA-Z0-9-\.]+@[\.a-zA-Z0-9-]+\.[a-zA-Z]+$/) != null); },
  is_engnumber: function() { return (this.match(/^[0-9a-zA-Z]+$/) != null); },
  is_engonly: function() { return (this.match(/^[a-zA-Z]+$/) != null); },
  is_number: function() { return (this.match(/^[0-9\.\-\\]+$/) != null); },

  is_handphone: function() { return (this.match(/^(01[01346-9])-?([1-9]{1}\d{2,3})-?(\d{4})$/) != null); },
  is_homephone: function() {
    return (this.match(/^(0[2-8][0-5]?)-?([1-9]{1}\d{2,3})-?(\d{4})$/) != null ||
      this.match(/^(1544|1566|1577|1588|1644|1688)-?(\d{4})$/) != null);
  },
  is_phone: function() {
    return (this.match(/^(0[2-8][0-5]?|01[01346-9])-?([1-9]{1}\d{2,3})-?(\d{4})$/) != null ||
      this.match(/^(1544|1566|1577|1588|1644|1688)-?(\d{4})$/) != null);
  },
  is_jumin: function() { return (this.match(/^(\d{2}[01]\d[0-3]\d)-?(\d{7})$/) != null && this.validate_jumin() ); },
  is_foreignerno: function() { return (this.match(/^(\d{2}[01]\d[0-3]\d)-?(\d{5}[7-9]\d{1})$/) != null && this.validate_foreignerno() ); },
  is_bizno: function() { return (this.match(/(\d{3})-?(\d{2})-?(\d{5})/) != null && this.validate_bizno() ); },

  validate_jumin: function() {
    var nsn = this.replace(/-/g, '');
    var s1 = nsn.substr(0,6);
    var s2 = nsn.substr(6,7);
    var n = 2;
    var sum = 0;
    for (i=0; i<s1.length; i++) sum += parseInt(s1.substr(i, 1)) * n++;
    for (i=0; i<s2.length-1; i++) {
      sum += parseInt(s2.substr(i, 1)) * n++;
      if (n == 10) n = 2;
    }
    c = 11 - sum % 11;
    if (c == 11) c = 1;
    if (c == 10) c = 0;
    if (c != parseInt(s2.substr(6, 1))) return false;
    return true;
  },

  validate_foreignerno: function() {
    var nsn = this.replace(/-/g, '');
    var sum=0;
    var odd=0;
    buf = new Array(13);
    for(i=0; i<13; i++) { buf[i]=parseInt(nsn.charAt(i)); }
    odd = buf[7]*10 + buf[8];
    if(odd%2 != 0) { return false; }
    if( (buf[11]!=6) && (buf[11]!=7) && (buf[11]!=8) && (buf[11]!=9) ) { return false; }
    var multipliers = new Array(2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5);
    for(i=0, sum=0; i<12; i++) { sum += (buf[i] *= multipliers[i]); }
    sum = 11 - (sum%11);
    if(sum >= 10) { sum -= 10; }
    sum += 2;
    if(sum >= 10) { sum -= 10; }
    if(sum != buf[12]) { return false }
    return true;
  },
  validate_bizno: function() {
    var nsn = this.replace(/-/g, '');
    var sum = 0;
    var getlist =new Array(10);
    var chkvalue =new Array(1, 3, 7, 1, 3, 7, 1, 3, 5);
    for(var i=0; i<10; i++) { getlist[i] = nsn.substring(i, i+1); }
    for(var i=0; i<9; i++) { sum += getlist[i]*chkvalue[i]; }
    sum = sum + parseInt((getlist[8]*5)/10);
    sidliy = sum % 10;
    sidchk = 0;
    if(sidliy != 0) { sidchk = 10 - sidliy; }
    else { sidchk = 0; }
    if(sidchk != getlist[9]) { return false; }
    return true;
  }
}

Object.extend(String.prototype, Validator);
