var FormUtil = Class.create();

FormUtil.prototype = {
  initialize: function(f, o, i) {
    var self = this;
    if(!f || f.tagName.toLowerCase() != 'form' || !o) { return; }
    f.FormUtil = self;
    $A(o.split(',')).each( function(n) { 
      switch(n) {
        case 'verify' :
          if(!f.onsubmit) { f.onsubmit = self.verify; }
          break;
        case 'autofocus' :
          $A($(f).getElementsByTagName('textarea')).each( function(e) { self.set_autofocus(e); });
          $A($(f).getElementsByTagName('select')).each( function(e) { self.set_autofocus(e); });
          $A($(f).getElementsByTagName('input'))
            .findAll( function(e) { return self.is_input_field(e); })
            .each( function(e) { self.set_autofocus(e); });
          break;
        case 'highlight' :
          $A($(f).getElementsByTagName('textarea')).each( function(e) { self.set_highlight(e); });
          $A($(f).getElementsByTagName('select')).each( function(e) { self.set_highlight(e); });
          $A($(f).getElementsByTagName('input'))
            .findAll( function(e) { return self.is_input_field(e); })
            .each( function(e) { self.set_highlight(e); });
          break;
      }
    } );
    if(i) { f[i].focus(); }
  },
  verify: function() {
    var errmsg = {
      'notempty' : '입력이 필요합니다',
      'email' : '이메일 형식이 아닙니다',
      'engnumber' : '영문과 숫자로만 입력해주세요',
      'engonly' : '영문으로 입력해주세요',
      'hangul' : '한글만 입력해주세요',
      'number' : '숫자만 입력해주세요',
      'handphone' : '핸드폰 번호만 입력해주세요',
      'homephone' : '일반 전화번호만 입력해주세요',
      'phone' : '전화번호만 입력해주세요',
      'jumin' : '주민번호만 입력해주세요',
      'foreignerno' : '외국인 등록번호만 입력해주세요',
      'bizno' : '사업자등록번호만 입력해주세요'
    };

    for(var i = 0; i < this.elements.length; i++) {
      e = this.elements[i];
      if(!e.verify) { continue; }
      ct = e.verify.split(":");
      if(ct[0] != 'notempty' && e.value.is_empty()) { continue; }
      switch(ct[0]) {
        case 'notempty' : if(!e.value.is_empty()) continue; break;
        case 'email' : if(e.value.is_email()) continue; break;
        case 'engnumber' : if(e.value.is_engnumber()) continue; break;
        case 'engonly' : if(e.value.is_engonly()) continue; break;
        case 'hangul' : if(e.value.is_hangul()) continue; break;
        case 'number' : if(e.value.is_number()) continue; break;
        case 'handphone' : if(e.value.is_handphone()) continue; break;
        case 'homephone' : if(e.value.is_homephone()) continue; break;
        case 'phone' : if(e.value.is_phone()) continue; break;
        case 'jumin' : if(e.value.is_jumin()) continue; break;
        case 'foreignerno' : if(e.value.is_foreignerno()) continue; break;
        case 'bizno' : if(e.value.is_bizno()) continue; break;
        default: continue;
      }

      e.focus();
      alert(((ct[1]) ? '['+ct[1]+'] ':'') + errmsg[ct[0]]);
      return false;
    }
  },
  set_autofocus: function(e) {
    e.onmouseover = function() { this.focus(); };
  },
  set_highlight: function(e) {
    e.onfocus = function() { $(this).addClassName("focus"); };
    e.onblur = function() { $(this).removeClassName("focus"); };
  },
  is_input_field: function(e) {
    if(!e || !e.type) return false;
    switch(e.type.toLowerCase()) {
      case 'text' :
      case 'password' :
        return true;
      default:
        return false;
    }
  }
}
