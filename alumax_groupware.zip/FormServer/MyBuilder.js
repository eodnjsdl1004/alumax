document.write('<object classid="clsid:3543897F-577B-4371-99E6-20EC4FA31A4F" id="View1" width="100%" height="100%" align="left" ');
document.write('codebase=/FormServer/Biin/MyBuilderViewer.cab#version=6,2,3,1"></object>');
document.write('<object classid="clsid:5220cb21-c88d-11cf-b347-00aa00a28331" width="0" height="0">');
document.write('<param name="LPKPath" value="/FormServer/Biin/MyBuilderViewer.lpk"> </object>');
//  document.write('<object classid="clsid:3543897F-577B-4371-99E6-20EC4FA31A4F" id="View1" width="100%" height="500" align="left" ');
//  document.write('codebase="/Biin/MyBuilderViewer.cab#version=6,2,3,1"></object>');
